package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Address;
import org.cap.model.Department;
import org.cap.model.Employee;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager= factory.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		
			Address address=new Address();
			address.setStreetName("South Avvenue");
			address.setCity("Mumbai");
			
			Address address1=new Address();
			address1.setStreetName("North Avvenue");
			address1.setCity("Chennai");
			
			Department department=new Department("Sales","NorthEast");
			
			Employee employee=new Employee("tom", "Jack", 120000);
		
		//  employee.getAddresses().add(address); employee.getAddresses().add(address1);
			employee.setDepartment(department);
		
			address.setEmployee(employee); address1.setEmployee(employee);
	
			
			entityManager.persist(employee);
			entityManager.persist(department);
			entityManager.persist(address);
			entityManager.persist(address1);
		transaction.commit();
		entityManager.close();
		factory.close();
		
		
		
	}

}
