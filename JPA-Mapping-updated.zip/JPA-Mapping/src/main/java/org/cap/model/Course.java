package org.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "course_seq",initialValue = 111)
public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "course_seq")
	private int courseId;
	private String courseName;
	
	@ManyToMany
	@JoinTable(name = "student_course",
			joinColumns = {@JoinColumn(name="courseId")},
			inverseJoinColumns = {@JoinColumn(name="studentId")})
	private List<Student> students=new ArrayList<>();

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public Course(String courseName) {
		super();
		this.courseName = courseName;
	}

	public Course() {
		super();
	}

	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + "]";
	}
	
	
	
}
