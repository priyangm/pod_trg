package org.cap.boot;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Address;
import org.cap.model.Department;
import org.cap.model.Employee;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager= factory.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		
		
		String query="from Employee e where e.salary > :param_salary";
		Query query2= entityManager.createQuery(query);
		query2.setParameter("param_salary", 5000.0);
		
		List<Employee> employees= query2.getResultList();
		for(Employee emp: employees)
			System.out.println(emp);
		
		
		
		
		
		
		
		
		
		//select query by Id
		/*
		 * Employee employee=entityManager.find(Employee.class, 1000);
		 * System.out.println(employee); employee.setSalary(34000);
		 */
		
		//delete query
		//entityManager.remove(employee);
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		 * Address address=new Address(); address.setStreetName("South Avvenue");
		 * address.setCity("Mumbai");
		 * 
		 * Address address1=new Address(); address1.setStreetName("North Avvenue");
		 * address1.setCity("Chennai");
		 * 
		 * Department department=new Department("Sales","NorthEast"); Department
		 * department1=new Department("Marketing","NorthEast"); Department
		 * department2=new Department("Finance","NorthEast");
		 * 
		 * Employee employee=new Employee("tom", "Jack", 120000); Employee employee1=new
		 * Employee("Jerry", "thomson", 45435); Employee employee2=new Employee("Ram",
		 * "Singh", 4566767); Employee employee3=new Employee("Annie", "George", 1200);
		 * 
		 * // employee.getAddresses().add(address);
		 * employee.getAddresses().add(address1); employee.setDepartment(department);
		 * employee1.setDepartment(department); employee2.setDepartment(department1);
		 * employee3.setDepartment(department2);
		 * 
		 * 
		 * address.setEmployee(employee); address1.setEmployee(employee);
		 * 
		 * 
		 * entityManager.persist(employee); entityManager.persist(employee1);
		 * entityManager.persist(employee2); entityManager.persist(employee3);
		 * entityManager.persist(department); entityManager.persist(department1);
		 * entityManager.persist(department2); entityManager.persist(address);
		 * entityManager.persist(address1);
		 */
		transaction.commit();
		entityManager.close();
		factory.close();
		
		
		
	}

}
