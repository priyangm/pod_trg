package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Course;
import org.cap.model.Student;

public class TestManyToMany {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager= factory.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			Student tom=new Student("Tom", "SouthAvvenue");
			Student Jack=new Student("Jack", "West car street");
			Student annie=new Student("Annie", "North Avvenue");
		
			Course java=new Course("JAVA-101");
			Course dotnet=new Course(".NET-102");
			Course oracle=new Course("ORACLE-145");
			
			
			tom.getCourses().add(oracle);
			tom.getCourses().add(java);
			Jack.getCourses().add(dotnet);
			Jack.getCourses().add(java);
			annie.getCourses().add(java);
			annie.getCourses().add(dotnet);
			annie.getCourses().add(oracle);
		
			
			entityManager.persist(tom);
			entityManager.persist(Jack);
			entityManager.persist(annie);
			entityManager.persist(java);
			entityManager.persist(dotnet);
			entityManager.persist(oracle);
			
			
			
		transaction.commit();
		entityManager.close();
		factory.close();
		
	}

}
