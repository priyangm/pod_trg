package org.cap.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

	@RequestMapping(value = "/checkLogin",method = RequestMethod.POST)
	public String validatelogin(
			@RequestParam("uname") String uname,
			@RequestParam("upwd")String upwd) {
		
		System.out.println("Check Login Executed..........");
		if(uname.equals("tom") && upwd.equals("tom123")) {
			return "success";
		}
		return "redirect:/";
				
	}
	
	
}
