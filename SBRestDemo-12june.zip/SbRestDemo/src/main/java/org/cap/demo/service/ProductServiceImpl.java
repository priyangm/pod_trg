package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IProductDBDao;
import org.cap.demo.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productService")
public class ProductServiceImpl implements IProductService{
	
	@Autowired
	private IProductDBDao productDBDao;

	@Override
	public List<Product> getAllProducts() {
		
		return productDBDao.findAll();
	}

	@Override
	public Product findProduct(Integer productId) {
		
		return productDBDao.getOne(productId);
	}

	@Override
	public List<Product> saveProduct(Product product) {
		productDBDao.save(product);
		return getAllProducts();
	}

	@Override
	public List<Product> filterByPriceDetails(double param_price) {
		// TODO Auto-generated method stub
		return productDBDao.filterByPriceDetails(param_price);
	}

	@Override
	public List<Product> findByProductName(String productName) {
		// TODO Auto-generated method stub
		return productDBDao.findByProductName(productName);
	}

}
