package org.cap.demo.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.model.Product;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao {
	private static AtomicInteger productId=new AtomicInteger(1000);
	private static List<Product> products=dummyDb();
	
	private static List<Product> dummyDb(){
		
		 List<Product> products=new ArrayList<Product>();
		 products.add(new Product(productId.getAndIncrement(), "Laptop", 12, 45000.0, LocalDate.of(2040, 3, 12)));
		 products.add(new Product(productId.getAndIncrement(), "Mobile", 3, 34000.0, LocalDate.of(2022, 3, 2)));
		 products.add(new Product(productId.getAndIncrement(), "IPOD", 22, 3400.0, LocalDate.of(2030, 5, 1)));
		 products.add(new Product(productId.getAndIncrement(), "IPAD", 67, 56000.0, LocalDate.of(2043, 3, 12)));
		 products.add(new Product(productId.getAndIncrement(), "Pendrive", 12, 1200.0, LocalDate.of(2039, 3, 12)));
		 
		 return products;
	}
	
	@Override
	public List<Product> getAllProducts() {
		
		return products;
	}

	@Override
	public Product findProduct(Integer productId) {
			for(Product product:products) {
				if(product.getProductId()==productId) {
					return product;
				}
			}
		
		return null;
	}

	@Override
	public List<Product> saveProduct(Product product) {
		
		products.add(product);
		return products;
	}

}
