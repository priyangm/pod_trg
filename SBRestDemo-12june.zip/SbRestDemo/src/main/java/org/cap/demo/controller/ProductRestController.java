package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.dao.IProductDao;
import org.cap.demo.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app/v1")
public class ProductRestController {
	@Autowired
	private IProductDao productDao;
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(
			@RequestBody Product product){
		List<Product> products= productDao.saveProduct(product);
		
		if(products==null|| products.isEmpty()) {
			return new ResponseEntity("Sorry! INsertion Failed!",
					HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);

	}
	
	
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> findProduct(
			@PathVariable("productId")Integer productId){
		Product product= productDao.findProduct(productId);
	
		if(product==null) {
			return new ResponseEntity("Sorry! Product ID not exits!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	

	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> products= productDao.getAllProducts();
	
		if(products==null|| products.isEmpty()) {
			return new ResponseEntity("Sorry! No Products available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
}
