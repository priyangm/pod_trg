package org.cap.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(value = {"handler","hibernateLazyInitializer"})
@Entity
@JacksonXmlRootElement(localName = "product")
public class Product {

	@Id
	@GeneratedValue
	@JacksonXmlProperty(localName = "pid",isAttribute = true)
	private int productId;
	
	@JacksonXmlProperty(localName = "name")
	private String productName;
	private int quantity;
	private double price;
	
	@OneToOne(cascade = CascadeType.REMOVE)
	@JoinColumn(name =  "manufacureId")
	private Manufacturer manufatcturer;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Manufacturer getManufatcturer() {
		return manufatcturer;
	}
	public void setManufatcturer(Manufacturer manufatcturer) {
		this.manufatcturer = manufatcturer;
	}
	public Product(int productId, String productName, int quantity, double price, Manufacturer manufatcturer) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.quantity = quantity;
		this.price = price;
		this.manufatcturer = manufatcturer;
	}
	public Product() {
		super();
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", quantity=" + quantity
				+ ", price=" + price + ", manufatcturer=" + manufatcturer + "]";
	}
	
	

}
