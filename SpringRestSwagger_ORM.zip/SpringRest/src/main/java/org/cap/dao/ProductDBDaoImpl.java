package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Product;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("productDbDao")
@Transactional
public class ProductDBDaoImpl implements IProductDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Product> getAllProducts() {
		List<Product> products= entityManager.createQuery("from Product").getResultList();
		return products;
	}

	@Override
	public Product findProduct(Integer productId) {
		Product product=entityManager.find(Product.class, productId);
		return product;
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		Product product=entityManager.find(Product.class, productId);
		entityManager.remove(product);
		return getAllProducts() ;
	}

}
