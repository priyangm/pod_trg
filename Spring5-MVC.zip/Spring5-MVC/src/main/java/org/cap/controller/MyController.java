package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.Registration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	
	@PostMapping("/storeRegister")
	public String storeRegistration(
				@ModelAttribute("register") Registration register ) {
		System.out.println(register);
		return "redirect:/";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		System.out.println("Hello Service Triggered...");
		String msg="Hello! Good Morning To All!";
		return new ModelAndView("welcome", "msg", msg);
	}
	
	@GetMapping("/register")
	public String showRegistrationPage(ModelMap map) {
		List<String> cities=new ArrayList<String>();
		cities.add("Chennai");
		cities.add("Mumbai");
		cities.add("Calcutta");
		cities.add("Pune");
		cities.add("Hyderabad");
		cities.add("Delhi");
		map.put("register", new Registration());
		map.put("cities", cities);
		
		return "registration";
	}
	
	
	@PostMapping("/checkLogin")
	public String validateLogin(@RequestParam("userName") String userName,
			@RequestParam("userPwd")String userPwd,
			ModelMap map) {
		
		if(userName.equals("tom") &&
				userPwd.equals("tom123")) {
			map.put("msg", "Welcome you are Authorized User!  <b>" + 
				userName +"</b>");
		}else {
			map.put("msg","Sorry! Login Failed! Not Authorized User!");
		}
		return "welcome";
		
	}
	
}
