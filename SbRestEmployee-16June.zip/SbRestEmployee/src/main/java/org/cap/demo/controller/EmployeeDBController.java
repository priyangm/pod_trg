package org.cap.demo.controller;

import java.util.List;


import org.cap.demo.dao.IAddressDBDao;
import org.cap.demo.dao.IEmployeeDBDao;
import org.cap.demo.model.Address;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
public class EmployeeDBController {

	@Autowired
	private IEmployeeDBDao employeeDbDao;
	
	@Autowired
	private IAddressDBDao addressDbDao;
	
	
	@GetMapping("/employees/{empId}")
	public ResponseEntity<Employee> findEmployee(
			@PathVariable("empId") Integer empId){
		Employee employee=employeeDbDao.getOne(empId);
		
		if(employee==null )
			return new ResponseEntity("Sorry! Employee Id not Available!",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployee(){
		List<Employee> employees=employeeDbDao.findAll();
		
		if(employees==null || employees.isEmpty())
			return new ResponseEntity("Sorry! No Employees Available!",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}
	
	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> saveEmployee(
			@RequestBody Employee employee){
		
		//employeeDbDao.save(employee);
		
		if(employee.getAddresses()!=null) {
			for(Address address:employee.getAddresses()) {
				address.setEmployee(employee);
				addressDbDao.save(address);
			}
		}
		
	
		List<Employee> employees=employeeDbDao.findAll();
		
		if(employees==null || employees.isEmpty())
			return new ResponseEntity("Sorry! No Employees Available!",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}
	
}
