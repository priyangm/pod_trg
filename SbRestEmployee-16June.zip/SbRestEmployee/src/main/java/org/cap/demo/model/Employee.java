package org.cap.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@SequenceGenerator(name = "myseq",initialValue = 1000)
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "myseq")
	private int employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	
	@JsonIgnoreProperties("employee")
	@OneToMany(targetEntity =Address.class,mappedBy = "employee" ,
			cascade = CascadeType.PERSIST)
	private List<Address> addresses=new ArrayList<>();
	
	
	
	@OneToOne (cascade = CascadeType.PERSIST)
	@JoinColumn(name="departId_fk")
	private Department department;
	
	
	
	
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public List<Address> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	public Employee(int employeeId, String firstName, String lastName, double salary, List<Address> addresses) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.addresses = addresses;
	}
	public Employee( String firstName, String lastName, double salary, List<Address> addresses) {
		super();
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.addresses = addresses;
	}
	
	public Employee( String firstName, String lastName, double salary) {
		super();
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		
	}
	
	public Employee() {
		super();
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", addresses=" + addresses + ", department=" + department + "]";
	}
	
	
	
	
	

}
